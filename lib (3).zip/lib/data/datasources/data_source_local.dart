import 'package:flutter/widgets.dart';

class DataSourceLocal extends ChangeNotifier {}
