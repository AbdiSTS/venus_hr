class Variables {
  static const String appName = 'com.example.nusantara_ess';
  static const String version = 'v1.8';

  // static const String baseUrl =
  //     'http://api.sinergiteknologi.co.id/VenusHR/api/mobile';
  static const String baseUrl =
      'http://api.nusantara-royalenfield.com/VenusHR/api/mobile';
  // flutter pub run build_runner build
}
